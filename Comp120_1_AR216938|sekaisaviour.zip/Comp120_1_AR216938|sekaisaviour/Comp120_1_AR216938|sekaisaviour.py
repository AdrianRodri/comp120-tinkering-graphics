import random
from PIL import Image

# Firstly we will generate a name
# More names can be added to the already existing
title = ['Lady', 'Lord', 'Admiral', 'Abbess', 'Abbot', 'Agha', 'Baron', 'Baroness']
first_name = ['Roger', 'Roberta', 'Ricard', 'Quentin']
last_name = ['Jeff', 'Catalist', 'Banana', 'Courgette']
place = ['Lothric', 'Mordor', 'Gondor', 'Falmouth']

# Randomly gets a word from each list
random_title = random.choice(title)
random_first_name = random.choice(first_name)
random_last_name = random.choice(last_name)
random_place = random.choice(place)

random_generated_name = random_title + random_first_name + random_last_name + ' of' + random_place
print(random_generated_name)

# Now we will create a .png image of the monster

# First lets generate 2 random numbers to select the 2 files to be merged
# Assuming we only have 5 images of each, hence the range
number_upperhalf = random.randint(1, 5)
number_lowerhalf = random.randint(1, 5)

if number_upperhalf == 1:
    monster_upperhalf = Image.open("1_monster_upperhalf.png")

elif number_upperhalf == 2:
    monster_upperhalf = Image.open("2_monster_upperhalf.png")

elif number_upperhalf == 3:
    monster_upperhalf = Image.open("3_monster_upperhalf.png")

elif number_upperhalf == 4:
    monster_upperhalf = Image.open("4_monster_upperhalf.png")

elif number_upperhalf == 5:
    monster_upperhalf = Image.open("5_monster_upperhalf.png")



if number_lowerhalf == 1:
    monster_lowerhalf = Image.open("2_monster_lowerrhalf.png")

elif number_lowerhalf == 2:
    monster_lowerhalf = Image.open("2_monster_lowerrhalf.png")

elif number_lowerhalf == 3:
    monster_lowerhalf = Image.open("3_monster_lowerhalf.png")

elif number_lowerhalf == 4:
    monster_lowerhalf = Image.open("4_monster_lowerhalf.png")

elif number_lowerhalf == 5:
    monster_lowerhalf = Image.open("5_monster_lowerhalf.png")

# Now we have 2 picked at random we can merge them
random_generated_monster = Image.blend(monster_upperhalf, monster_lowerhalf, 0.5)

# Now we need to save the file and make sure we can save many more after that

number_list = list(range(1,99999999999999999999999999))
number_random = random.sample(number_list, k=1)

Image.save('randomly generated monster' + number_random)
Image._show()